To run the model, just enter
>> n_runModel
into Matlab.

If you use this, please cite
Said and Heeger (2013) A model of binocular rivalry and cross-orientation
suppression. PLOS Computational Biology.

If you modify and distribute the code, please include this README.txt file.

This work is licensed under a Creative Commons Attribution-ShareAlike 3.0 Unported License.