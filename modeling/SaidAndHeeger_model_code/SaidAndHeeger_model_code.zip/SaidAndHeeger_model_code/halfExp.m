function [x] = halfExp(base,n)
x = (max(0,base)).^n;